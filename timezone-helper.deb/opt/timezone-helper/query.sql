CREATE TABLE `time_keeper` (`idnew_table` int NOT NULL AUTO_INCREMENT, `timestamp` varchar(45) DEFAULT NULL, PRIMARY KEY (`idnew_table`)) ENGINE=InnoDB AUTO_INCREMENT=28;
