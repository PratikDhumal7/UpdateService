#!/usr/bin/env bash

source /etc/timezone-helper/timezone-helper.conf

echo "Running timezone-helper java application."
java -jar ${EXECUTABLE_FILE_PATH}/timezone-helper-1.0-shaded.jar \
 --repeat.interval.ms ${REPEAT_INTERVAL_MS} \
 --timezone ${TIMEZONE} \
 --log.file.path ${LOG_FILE_PATH} \


 

